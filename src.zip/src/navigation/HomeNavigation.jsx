import { View, Text } from 'react-native'
import React from 'react'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import HomeDrawer from './HomeDrawer'
import { DaliyExpenseProvide } from '../context/dailyExpense'
const TabNavi=createBottomTabNavigator()
const HomeNavigation = () => {
  return (
    <DaliyExpenseProvide>
    <TabNavi.Navigator 
    screenOptions={{headerShown:false}}
    >
        <TabNavi.Screen
        name="HomeTab"
        component={HomeDrawer}
        />
    </TabNavi.Navigator>
    </DaliyExpenseProvide>
  )
}

export default HomeNavigation