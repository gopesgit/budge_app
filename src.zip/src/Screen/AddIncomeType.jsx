import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const AddIncomeType = () => {
  return (
    <View>
      <Text>AddIncomeType</Text>
    </View>
  )
}

export default AddIncomeType

const styles = StyleSheet.create({})