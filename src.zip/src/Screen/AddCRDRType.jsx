import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const AddCRDRType = () => {
  return (
    <View>
      <Text>AddCRDRType</Text>
    </View>
  )
}

export default AddCRDRType

const styles = StyleSheet.create({})