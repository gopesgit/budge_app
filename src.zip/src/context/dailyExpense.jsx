import { createContext, useEffect, useState } from "react";
import { collection, getDocs, getFirestore, orderBy, query, where } from "firebase/firestore";
import { firebaseapp } from "../firebase/configurFirebase";

export const DaliyExpenseContext=createContext("")
export const DaliyExpenseProvide=({children})=>{
    const [expenseType,setExpenseType]=useState()
    const [fundType, setfundType] = useState()
    const db=getFirestore(firebaseapp)
    useEffect(()=>{
        getExpenseTypeList()
        getFundTypeList()
    },[])
    const getExpenseTypeList=async ()=>{
        //console.log("Inside getExpense List");
        try {
            const expenseRef=await collection(db,"expenseTypes")
            const q = await query(expenseRef, orderBy("label","asc"))
            const querySnapdhot = await getDocs(q)
            if (!querySnapdhot.empty) {
                setExpenseType([])
                const expenseItem=querySnapdhot.docs.map(doc => ({ id: doc.id, ...doc.data() }))  
                setExpenseType(expenseItem);        
            }
        } catch (error) {
            console.log(error);
        }
    }
    const getFundTypeList=async ()=>{
        try {
            const expenseRef=await collection(db,"User")
            const q = await query(expenseRef, where("name","==","Bappa Das"))
            const querySnapdhot = await getDocs(q)
            if (!querySnapdhot.empty) {
                setfundType()
                const userdata=querySnapdhot.docs.map(doc => ({ id: doc.id, ...doc.data() }))  
                const fundItem=userdata[0].funds;
                setfundType(fundItem)        
            }
        } catch (error) {
            console.log(error);
        }
    }
    return(
        <DaliyExpenseContext.Provider value={{expenseType,fundType}}>
            {children}
        </DaliyExpenseContext.Provider>
    )
}