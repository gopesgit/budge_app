export const addExpense=async ()=>{
    console.log("OK");
}